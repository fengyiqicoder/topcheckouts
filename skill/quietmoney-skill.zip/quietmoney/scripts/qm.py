#!/usr/bin/env python3
"""quietmoney CLI：查本地数据包（15,000 个往收银台导流的网站 + 606 个入选站档案），不联网。
数据包位置（按顺序找）：环境变量 QUIETMONEY_DATA（.db 文件或所在目录）→ skill 目录下 data/quietmoney.db → ~/.config/quietmoney/quietmoney.db
用法：
  qm.py top   [--by last|gain|growth] [-n 20] [--gateway X] [--industry X] [--listed] [--min-last N] [--min-prev N] [--fire 标签] [--src 标签] [--year 2026] [--lang en] [--json]
  qm.py search <关键词> [同上筛选参数]
  qm.py site <domain> [--lang en] [--full] [--json]
  qm.py stats [--json]
  qm.py info                数据包版本、月份、站数"""
import sys, os, json, argparse, sqlite3, pathlib
HERE = pathlib.Path(__file__).resolve().parent.parent
BUY = 'https://topcheckouts.000ooo.ooo/pro/'
MAX_LIMIT = 500

def db_path():
    env = os.environ.get('QUIETMONEY_DATA', '').strip()
    cands = ([pathlib.Path(env).expanduser() / 'quietmoney.db', pathlib.Path(env).expanduser()] if env else []) + \
            [HERE / 'data/quietmoney.db', pathlib.Path('~/.config/quietmoney/quietmoney.db').expanduser()]
    for p in cands:
        if p.is_file(): return p
    sys.exit(f'没找到数据包：在 {BUY} 购买（¥29 一次性），把下载的 zip 解压到 {HERE / "data"}/ ，或设置 QUIETMONEY_DATA 指向解压目录。')
def ddb():
    c = sqlite3.connect(f'file:{db_path()}?mode=ro', uri=True); c.row_factory = sqlite3.Row; return c

# ---------------- 查询（与原 API 同口径） ----------------
SITE_COLS = 'domain,sep,aug,jul,aprjun,gain,growth,gateways,gw_count,new_only,global_rank,industry,listed,listed_rank,type_zh,fire,src,engine,takeoff_year,summary_zh,summary_en'
SORTS = {'last': 'sep', 'sep': 'sep', 'gain': 'gain', 'growth': 'growth', 'prev': 'aug', 'aug': 'aug', 'aprjun': 'aprjun', 'rank': 'global_rank', 'domain': 'domain'}
def row_out(r, lang='zh'):
    d = dict(r); d['listed'] = bool(d['listed']); d['new_only'] = bool(d['new_only'])
    d['summary'] = d.pop('summary_en') if lang == 'en' and d.get('summary_en') else d.pop('summary_zh'); d.pop('summary_en', None)
    if d['listed']: d['page'] = f"https://topcheckouts.000ooo.ooo{'/en' if lang == 'en' else ''}/s/{d['domain']}/"
    return {k: v for k, v in d.items() if v is not None}
def q_sites(p):
    w, a = [], []
    if p.get('q'): w.append('(domain LIKE ? OR summary_zh LIKE ? OR summary_en LIKE ? OR industry LIKE ?)'); a += [f'%{p["q"]}%'] * 4
    if p.get('gateway'): w.append('gateways LIKE ?'); a.append(f'%{p["gateway"]}%')
    if p.get('industry'): w.append('industry LIKE ?'); a.append(f'%{p["industry"]}%')
    if p.get('listed') is True: w.append('listed=1')
    if p.get('listed') is False: w.append('listed=0')
    if p.get('new_only'): w.append('new_only=1')
    for k, col, op in (('min_sep', 'sep', '>='), ('min_gain', 'gain', '>='), ('min_aug', 'aug', '>=')):
        if p.get(k) is not None: w.append(f'{col} {op} ?'); a.append(int(p[k]))
    for k in ('fire', 'src', 'engine'):
        if p.get(k): w.append(f'{k}=?'); a.append(p[k])
    if p.get('year'): w.append('takeoff_year=?'); a.append(p['year'])
    sort = SORTS[p.get('sort') or 'last']
    order = 'ASC' if sort in ('global_rank', 'domain') else 'DESC'
    lim = max(1, min(MAX_LIMIT, int(p.get('limit') or 20))); off = max(0, int(p.get('offset') or 0))
    where = ('WHERE ' + ' AND '.join(w)) if w else ''
    nul = f'{sort} IS NULL, ' if sort in ('growth', 'global_rank') else ''
    with ddb() as c:
        total = c.execute(f'SELECT count(*) FROM sites {where}', a).fetchone()[0]
        rs = c.execute(f'SELECT {SITE_COLS} FROM sites {where} ORDER BY {nul}{sort} {order} LIMIT ? OFFSET ?', a + [lim, off]).fetchall()
    return {'total': total, 'offset': off, 'limit': lim, 'sort': p.get('sort') or 'last', 'sites': [row_out(r, p.get('lang') or 'zh') for r in rs]}
def q_site(domain, lang):
    domain = domain.lower().strip().removeprefix('https://').removeprefix('http://').removeprefix('www.').split('/')[0]
    with ddb() as c:
        r = c.execute(f'SELECT {SITE_COLS},per_gw FROM sites WHERE domain=?', (domain,)).fetchone()
        if not r: return None
        out = row_out({k: r[k] for k in r.keys() if k != 'per_gw'}, lang); out['per_gateway'] = json.loads(r['per_gw'])
        if r['listed']:
            has = c.execute('SELECT body FROM dossiers WHERE domain=? AND lang=?', (domain, lang)).fetchone()
            dz = has or c.execute("SELECT body FROM dossiers WHERE domain=? AND lang='zh'", (domain,)).fetchone()
            out['dossier'] = json.loads(dz['body']); out['dossier_lang'] = lang if has else 'zh'
            t = c.execute('SELECT body FROM traffic WHERE domain=?', (domain,)).fetchone(); out['traffic'] = json.loads(t['body']) if t else None
    return out
def q_stats():
    with ddb() as c:
        meta = {r['k']: r['v'] for r in c.execute('SELECT k,v FROM meta')}
        by_gw = []
        for g in json.loads(meta['gateways']):
            r = c.execute('SELECT count(*), sum(sep), sum(gain) FROM sites WHERE gateways LIKE ? AND sep>0', (f'%{g}%',)).fetchone()
            by_gw.append({'gateway': g, 'sites_with_visits_last_month': r[0], 'last_month_sum': r[1] or 0, 'gain_sum': r[2] or 0})
        by_ind = [dict(r) for r in c.execute("SELECT industry, count(*) sites, sum(sep) last_month_sum, sum(gain) gain_sum FROM sites WHERE sep>0 AND industry!='' GROUP BY industry ORDER BY last_month_sum DESC LIMIT 40")]
        fire = [dict(r) for r in c.execute('SELECT fire, count(*) n, sum(sep) last_month_sum FROM sites WHERE listed=1 GROUP BY fire ORDER BY n DESC')]
        src = [dict(r) for r in c.execute('SELECT src, count(*) n, sum(sep) last_month_sum FROM sites WHERE listed=1 GROUP BY src ORDER BY n DESC')]
    return {'by_gateway': sorted(by_gw, key=lambda x: -x['last_month_sum']), 'by_industry': by_ind, 'listed_by_how_it_started': fire, 'listed_by_source_now': src}

# ---------------- 输出 ----------------
fmt = lambda n: '' if n is None else f'{n:,}' if isinstance(n, int) else str(n)
def table(rows, cols):
    print('| ' + ' | '.join(h for h, _ in cols) + ' |'); print('|' + '---|' * len(cols))
    for r in rows: print('| ' + ' | '.join(str(f(r)).replace('|', '/').replace('\n', ' ') for _, f in cols) + ' |')
def growth(r):
    g = r.get('growth'); return 'new' if g is None and r.get('sep') else ('' if g is None else f'{g:+.0f}%')
COLS = [('#', lambda r: r['_i']), ('domain', lambda r: r['domain']), ('last month', lambda r: fmt(r['sep'])), ('month before', lambda r: fmt(r['aug'])), ('gain', lambda r: fmt(r['gain'])),
        ('MoM', growth), ('4–6 mo ago avg', lambda r: fmt(r['aprjun'])), ('checkouts', lambda r: r.get('gateways', '')), ('industry', lambda r: r.get('industry', '')[:28]),
        ('listed', lambda r: f"#{r['listed_rank']} {r.get('fire', '')}/{r.get('src', '')}" if r.get('listed') else ''), ('summary', lambda r: (r.get('summary') or '')[:70])]

def cmd_list(a, q=None):
    p = {'q': q, 'sort': a.by, 'limit': a.n, 'offset': a.offset, 'gateway': a.gateway, 'industry': a.industry, 'listed': True if a.listed else (False if a.unlisted else None),
         'min_sep': a.min_last, 'min_aug': a.min_prev, 'min_gain': a.min_gain, 'fire': a.fire, 'src': a.src, 'engine': a.engine, 'year': a.year, 'lang': a.lang, 'new_only': a.new_only}
    r = q_sites(p)
    if a.json: return print(json.dumps(r, ensure_ascii=False, indent=1))
    print(f"共 {r['total']:,} 个匹配，显示 {r['offset']+1}–{r['offset']+len(r['sites'])}，排序 {r['sort']}（付费页访问 = Similarweb 估算的跳到收银台的访问次数，不是收入）\n")
    for i, s in enumerate(r['sites'], r['offset'] + 1): s['_i'] = i
    table(r['sites'], COLS)
def cmd_site(a):
    r = q_site(a.domain, a.lang)
    if not r: sys.exit(f'数据包里没有 {a.domain}（只收录前 15,000 个站）。')
    if a.json: return print(json.dumps(r, ensure_ascii=False, indent=1))
    print(f"# {r['domain']}\n")
    print(f"付费页访问：上 4–6 个月均 {fmt(r['aprjun'])} → 上三个月 {fmt(r['jul'])} → 上两个月 {fmt(r['aug'])} → 上个月 {fmt(r['sep'])}（环比 {growth(r)}，净增 {fmt(r['gain'])}）")
    print(f"收银台：{r.get('gateways')}；全球排名 {fmt(r.get('global_rank'))}；行业 {r.get('industry', '')}")
    if len(r.get('per_gateway') or {}) > 1:
        print('\n| checkout | 4–6 mo ago avg | 3 mo ago | 2 mo ago | last month |\n|---|---|---|---|---|')
        for g, v in sorted(r['per_gateway'].items(), key=lambda kv: -kv[1].get('Sep', 0)): print(f"| {g} | {fmt(v.get('AprJun'))} | {fmt(v.get('Jul'))} | {fmt(v.get('Aug'))} | {fmt(v.get('Sep'))} |")
    if not r.get('listed'): return print('\n（不在 606 个入选站里，没有档案。）')
    print(f"\n入选第 {r['listed_rank']} 名 · 起步方法：{r.get('fire')} · 现在新客来源：{r.get('src')} · 增长引擎：{r.get('engine')} · 起飞 {r.get('takeoff_year', '?')}\n页面：{r.get('page')}\n")
    d = r['dossier']; full = a.full; p, c, g = d['product'], d['channels'], d['growth_path']
    if r.get('dossier_lang') == 'en':
        print(f"## Product\n{p.get('summary')}\nUsers: {p.get('users')}\nPositioning: {p.get('positioning')}\nPricing: {(p.get('pricing') or {}).get('text')}\n")
        print(f"## Channels\nNew-user source: {c.get('new_user_source')}; countries: {c.get('countries')}; language: {c.get('language')}\n{c.get('summary')}\n")
        print(f"## Growth path\n{g.get('one_line_story')}\n")
        for k, h in (('growth_loop', 'Growth loop'), ('timeline', 'Timeline'), ('basics', 'Basics'), ('revenue_clues', 'Revenue clues'), ('confidence_and_gaps', 'Confidence and gaps')):
            if g.get(k) and (full or k == 'growth_loop'): print(f"### {h}\n{g[k]}\n")
    else:
        pr = p.get('定价') or {}
        print(f"## 产品\n{p.get('产品总结')}\n用户群体：{p.get('用户群体')}\n定位：{p.get('定位')}\n定价：{pr.get('文字') if isinstance(pr, dict) else pr}\n")
        print(f"## 渠道\n新客来源：{c.get('新客来源')}；国家：{c.get('国家')}；语言：{c.get('语言')}\n{c.get('渠道总结')}\n")
        print(f"## 发家路径\n{g.get('一句话发家逻辑')}\n")
        for k in ('增长循环', '时间线', '基本信息', '收入与规模线索', '可信度与缺口'):
            if g.get(k) and (full or k == '增长循环'): print(f"### {k}\n{g[k]}\n")
    if not full: print('（加 --full 看时间线、基本信息、收入线索、可信度；加 --json 看全部原始字段，包括流量明细。）')
def cmd_stats(a):
    r = q_stats()
    if a.json: return print(json.dumps(r, ensure_ascii=False, indent=1))
    print('## 按收银台（上个月有访问的网站）'); table(r['by_gateway'], [('checkout', lambda x: x['gateway']), ('sites', lambda x: fmt(x['sites_with_visits_last_month'])), ('last month sum', lambda x: fmt(x['last_month_sum'])), ('gain sum', lambda x: fmt(x['gain_sum']))])
    print('\n## 按行业（前 20）'); table(r['by_industry'][:20], [('industry', lambda x: x['industry']), ('sites', lambda x: fmt(x['sites'])), ('last month sum', lambda x: fmt(x['last_month_sum'])), ('gain sum', lambda x: fmt(x['gain_sum']))])
    print('\n## 入选站：起步方法'); table(r['listed_by_how_it_started'], [('起步方法', lambda x: x['fire']), ('站数', lambda x: x['n']), ('last month sum', lambda x: fmt(x['last_month_sum']))])
    print('\n## 入选站：现在新客来源'); table(r['listed_by_source_now'], [('来源', lambda x: x['src']), ('站数', lambda x: x['n']), ('last month sum', lambda x: fmt(x['last_month_sum']))])
def cmd_info(a):
    with ddb() as c: m = {r['k']: r['v'] for r in c.execute('SELECT k,v FROM meta')}
    print(json.dumps({'data_file': str(db_path()), **m}, ensure_ascii=False, indent=1))

ap = argparse.ArgumentParser(description='quietmoney local data CLI'); sp = ap.add_subparsers(dest='cmd', required=True)
def filters(p):
    p.add_argument('--by', default='last', choices=list(SORTS)); p.add_argument('-n', type=int, default=20); p.add_argument('--offset', type=int, default=0)
    for f in ('gateway', 'industry', 'fire', 'src', 'engine', 'year', 'lang'): p.add_argument('--' + f)
    for f in ('min-last', 'min-prev', 'min-gain'): p.add_argument('--' + f, type=int)
    p.add_argument('--min-sep', dest='min_last', type=int, help=argparse.SUPPRESS); p.add_argument('--min-aug', dest='min_prev', type=int, help=argparse.SUPPRESS)
    p.add_argument('--listed', action='store_true'); p.add_argument('--unlisted', action='store_true'); p.add_argument('--new-only', action='store_true'); p.add_argument('--json', action='store_true')
filters(sp.add_parser('top')); s = sp.add_parser('search'); s.add_argument('query'); filters(s)
s = sp.add_parser('site'); s.add_argument('domain'); s.add_argument('--lang', default='zh'); s.add_argument('--full', action='store_true'); s.add_argument('--json', action='store_true')
s = sp.add_parser('stats'); s.add_argument('--json', action='store_true')
sp.add_parser('info')
a = ap.parse_args()
{'top': lambda: cmd_list(a), 'search': lambda: cmd_list(a, a.query), 'site': lambda: cmd_site(a), 'stats': lambda: cmd_stats(a), 'info': lambda: cmd_info(a)}[a.cmd]()
