---
name: quietmoney
description: Query the quietmoney (闷声发大财) data pack - 15,000 websites that send visitors to Stripe, Paddle, Gumroad, Lemon Squeezy, Polar, Creem, Whop and 21 other checkout domains, with monthly checkout visits for the last 6 months, plus full product / channel / growth-path dossiers for 606 hand-checked bootstrapped sites. Use when the user asks which indie or bootstrapped products are making money, which sites grew checkout traffic fastest, what a specific domain earns or how it got its first users, which checkout a site uses, niche or idea research backed by real payment-page traffic, or says quietmoney / 闷声发大财 / 收银台流量 / 付费页访问 / 发家路径. Reads a local data pack (bought once at quietmoney.000ooo.ooo/pro/); no network needed.
---

# quietmoney

You have a CLI that queries the local quietmoney data pack (SQLite, offline). Run it with Bash:

```bash
python3 ~/.claude/skills/quietmoney/scripts/qm.py <command> [options]
```

If the skill lives elsewhere, use the `scripts/qm.py` next to this file.

## Data pack

The CLI looks for `quietmoney.db` in `$QUIETMONEY_DATA` (file or folder), then `data/` next to this file, then `~/.config/quietmoney/`. If it exits with "没找到数据包", tell the user to buy the pack at https://quietmoney.000ooo.ooo/pro/ (¥29, one-time) and unzip it into the `data/` folder of this skill. `qm.py info` shows which pack is in use and its months.

## Commands

| goal | command |
|---|---|
| biggest checkout traffic last month | `qm.py top --by last -n 20` |
| largest gain, last month vs the month before | `qm.py top --by gain -n 20` |
| fastest % growth, skip tiny bases | `qm.py top --by growth --min-prev 3000 -n 20` |
| only the 606 hand-checked sites | add `--listed` |
| sites using one checkout | `--gateway gumroad.com` (also `buy.stripe.com`, `paddle`, `whop.com`, `polar.sh`, `ko-fi.com`…) |
| by industry | `--industry Games` (Similarweb industry, substring) |
| listed sites by how they started | `--listed --fire 外部事件顺风` (labels: 已有圈子迁移 搜索长尾 主播或媒体点燃 依附上游流量 花钱买量 首发平台 抢新平台窗口 外部事件顺风 机构分发 熟人圈起步) |
| listed sites by new-user source now | `--listed --src SEO` (SEO GEO 社交媒体 病毒传播 其他) |
| listed sites by take-off year | `--listed --year 2026` |
| keyword search | `qm.py search "pdf" --by gain` |
| one site in depth | `qm.py site tally.so` (add `--full` for timeline, basics, revenue clues; `--lang en` for English; `--json` for every raw field incl. countries, keywords, referrers) |
| totals by checkout / industry / class | `qm.py stats` |
| pack version and months | `qm.py info` |

Paging: `-n` up to 500, `--offset`. Every list command accepts `--json`.

## How to answer

1. Pick the narrowest command that answers the question; chain a `top`/`search` with a few `site` calls when the user wants the "why".
2. Say what the number is: "checkout visits" are Similarweb estimates of visits from the site to a checkout page. They are not payments and not revenue. Small sites sit on fixed buckets (4,298 / 12,894 / 21,490 …), so treat small differences as noise.
3. For listed sites, the dossier separates evidence from speculation; keep that distinction when you summarize, and cite the evidence links from the timeline when the user asks how a site grew.
4. Columns: `sep` = last month, `aug` = the month before, `jul` = three months ago, `aprjun` = average of 4–6 months ago. When you answer, say "last month" / "the month before" rather than month names.
5. Unlisted sites have numbers but no dossier; they may be big brands, funded companies, marketplaces or ad-driven, which is why they were not listed.
6. Reply in the user's language. Use tables for lists of sites.

The pack is refreshed on the 20th of each month; buyers re-download the new version from their original order link.
